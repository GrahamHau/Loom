(function registerXhsExtractor() {
  window.__pmcopilot_extractors = window.__pmcopilot_extractors || {};
  window.__pmcopilot_extractors.xiaohongshu = function extractXhs() {
    const text = (selector) => document.querySelector(selector)?.textContent?.trim() || "";
    const first = (selectors, root = document) => {
      for (const selector of selectors) {
        const el = root.querySelector(selector);
        if (el) return el;
      }
      return null;
    };
    const normalizeImageUrl = (url) => {
      if (!url) return "";
      const value = String(url).trim();
      if (!value || value.startsWith("data:")) return "";
      try {
        return new URL(value, window.location.href).toString();
      } catch {
        return value;
      }
    };
    const cssImageUrl = (value) => {
      const match = String(value || "").match(/url\((['"]?)(.*?)\1\)/i);
      return normalizeImageUrl(match?.[2] || "");
    };
    const titleNode = first(["#detail-title", ".title", "h1"]);
    const candidateRootSelectors = [
      "#noteContainer",
      ".note-container",
      "[class*='noteContainer']",
      "[class*='note-container']",
      "[class*='detail-container']",
      "[class*='detailContainer']",
      "[class*='overlay']",
      "[class*='modal']",
      "[class*='dialog']",
      "[class*='mask']",
      "[class*='popup']",
    ].join(",");
    const hasMedia = (node) => {
      if (!node) return false;
      return Boolean(node.querySelector([
        "video",
        "img",
        "[style*='background-image']",
        "[class*='media']",
        "[class*='player']",
        "[class*='video']",
      ].join(",")));
    };
    const rootScore = (node) => {
      const rect = node.getBoundingClientRect();
      const area = Math.max(rect.width, 0) * Math.max(rect.height, 0);
      const titleBonus = titleNode && node.contains(titleNode) ? 1_000_000 : 0;
      const mediaBonus = hasMedia(node) ? 1_500_000 : 0;
      const widthBonus = rect.width > window.innerWidth * 0.55 ? 500_000 : 0;
      return area + titleBonus + mediaBonus + widthBonus;
    };
    const findNoteRoot = () => {
      if (titleNode) {
        const ancestors = [];
        let current = titleNode.parentElement;
        let depth = 0;
        while (current && depth < 8) {
          if (current.matches(candidateRootSelectors) || hasMedia(current)) ancestors.push(current);
          current = current.parentElement;
          depth += 1;
        }
        const rankedAncestors = ancestors
          .map((node) => ({ node, score: rootScore(node) }))
          .sort((a, b) => b.score - a.score);
        if (rankedAncestors[0]?.node) return rankedAncestors[0].node;
      }

      const candidates = Array.from(document.querySelectorAll(candidateRootSelectors));

      const scored = candidates
        .map((node) => ({ node, score: rootScore(node) }))
        .sort((a, b) => b.score - a.score);
      return scored[0]?.node || document;
    };
    const noteRoot = findNoteRoot();
    const isBadImage = (url) => {
      const value = String(url || "").toLowerCase();
      return !value ||
        value.includes("logo") ||
        value.includes("favicon") ||
        value.includes("avatar") ||
        value.includes("default") ||
        value.includes("placeholder") ||
        value.includes("sns-webpic-qc.xhscdn.com") && value.includes("logo");
    };
    const isIrrelevantNode = (node) => {
      const badContainer = node.closest([
        "[class*='avatar']",
        "[class*='author']",
        "[class*='user']",
        "[class*='comment']",
        "[class*='recommend']",
        "[class*='related']",
        "[class*='sidebar']",
        "[class*='aside']",
        "[class*='nav']",
        "[class*='toolbar']",
      ].join(","));
      return Boolean(badContainer);
    };
    const visibleScore = (img) => {
      const rect = img.getBoundingClientRect();
      const width = img.naturalWidth || rect.width || 0;
      const height = img.naturalHeight || rect.height || 0;
      if (width < 160 || height < 120) return 0;
      const area = width * height;
      const inViewportBonus = rect.top < window.innerHeight && rect.bottom > 0 ? 500000 : 0;
      const leftPaneBonus = rect.left < window.innerWidth * 0.55 ? 300000 : 0;
      const rootBonus = noteRoot.contains(img) ? 700000 : 0;
      return area + inViewportBonus + leftPaneBonus + rootBonus;
    };
    const backgroundScore = (node) => {
      const rect = node.getBoundingClientRect();
      const width = rect.width || 0;
      const height = rect.height || 0;
      if (width < 160 || height < 120) return 0;
      const area = width * height;
      const inViewportBonus = rect.top < window.innerHeight && rect.bottom > 0 ? 500000 : 0;
      const leftPaneBonus = rect.left < window.innerWidth * 0.55 ? 300000 : 0;
      const rootBonus = noteRoot.contains(node) ? 700000 : 0;
      return area + inViewportBonus + leftPaneBonus + rootBonus;
    };
    const extractMediaUrlFromNode = (node) => {
      if (!node || !(node instanceof Element)) return "";
      const directImg = node.tagName === "IMG" ? node : node.querySelector("img");
      const directImgUrl = normalizeImageUrl(
        directImg?.currentSrc ||
        directImg?.getAttribute("src") ||
        directImg?.getAttribute("data-src") ||
        directImg?.getAttribute("data-xhs-img")
      );
      if (directImgUrl && !isBadImage(directImgUrl)) return directImgUrl;

      const directVideo = node.tagName === "VIDEO" ? node : node.querySelector("video");
      const posterUrl = normalizeImageUrl(directVideo?.getAttribute("poster"));
      if (posterUrl && !isBadImage(posterUrl)) return posterUrl;

      const directStyleUrl = cssImageUrl(node instanceof HTMLElement ? node.style?.backgroundImage : "");
      if (directStyleUrl && !isBadImage(directStyleUrl)) return directStyleUrl;

      const computedStyleUrl = cssImageUrl(window.getComputedStyle(node).backgroundImage);
      if (computedStyleUrl && !isBadImage(computedStyleUrl)) return computedStyleUrl;

      const descendants = node.querySelectorAll("*");
      for (const child of descendants) {
        const childStyleUrl = cssImageUrl(child instanceof HTMLElement ? child.style?.backgroundImage : "");
        if (childStyleUrl && !isBadImage(childStyleUrl)) return childStyleUrl;
        const childComputedUrl = cssImageUrl(window.getComputedStyle(child).backgroundImage);
        if (childComputedUrl && !isBadImage(childComputedUrl)) return childComputedUrl;
      }
      return "";
    };
    const viewportMediaScore = (node) => {
      const rect = node.getBoundingClientRect();
      const width = rect.width || 0;
      const height = rect.height || 0;
      if (width < window.innerWidth * 0.18 || height < window.innerHeight * 0.22) return 0;
      if (rect.left > window.innerWidth * 0.58) return 0;
      if (rect.top > window.innerHeight * 0.3) return 0;
      const area = width * height;
      const leftBonus = (window.innerWidth * 0.58 - Math.max(rect.left, 0)) * 1000;
      const topBonus = (window.innerHeight * 0.35 - Math.max(rect.top, 0)) * 800;
      return area + leftBonus + topBonus;
    };
    const pickPointSampleThumbnail = () => {
      const points = [
        [0.22, 0.28],
        [0.22, 0.45],
        [0.22, 0.62],
        [0.30, 0.28],
        [0.30, 0.45],
        [0.30, 0.62],
        [0.38, 0.28],
        [0.38, 0.45],
        [0.38, 0.62],
      ];
      const ranked = [];
      for (const [xRatio, yRatio] of points) {
        const x = Math.round(window.innerWidth * xRatio);
        const y = Math.round(window.innerHeight * yRatio);
        const stack = typeof document.elementsFromPoint === "function" ? document.elementsFromPoint(x, y) : [];
        for (const node of stack) {
          if (!(node instanceof Element) || isIrrelevantNode(node)) continue;
          const url = extractMediaUrlFromNode(node);
          if (!url) continue;
          const score = viewportMediaScore(node);
          if (score > 0) ranked.push({ url, score, point: [x, y], tag: node.tagName, className: node.className || "" });
        }
      }
      const best = ranked.sort((a, b) => b.score - a.score);
      return { url: best[0]?.url || "", source: "point-sample", top: best.slice(0, 8) };
    };
    const pickViewportThumbnail = () => {
      const pointSample = pickPointSampleThumbnail();
      if (pointSample.url) return pointSample;

      const imgCandidates = Array.from(document.querySelectorAll("img"));
      const rankedImages = imgCandidates
        .map((img) => {
          if (isIrrelevantNode(img)) return { url: "", score: 0 };
          const url = normalizeImageUrl(img.currentSrc || img.src || img.getAttribute("src") || img.getAttribute("data-src"));
          return { url, score: viewportMediaScore(img) };
        })
        .filter((item) => item.score > 0 && !isBadImage(item.url))
        .sort((a, b) => b.score - a.score);
      if (rankedImages[0]?.url) return { url: rankedImages[0].url, source: "viewport-image", top: rankedImages.slice(0, 5) };

      const videoCandidates = Array.from(document.querySelectorAll("video[poster]"));
      const rankedVideos = videoCandidates
        .map((video) => ({
          url: normalizeImageUrl(video.getAttribute("poster")),
          score: viewportMediaScore(video),
        }))
        .filter((item) => item.score > 0 && !isBadImage(item.url))
        .sort((a, b) => b.score - a.score);
      if (rankedVideos[0]?.url) return { url: rankedVideos[0].url, source: "viewport-video-poster", top: rankedVideos.slice(0, 5) };

      const bgCandidates = Array.from(document.querySelectorAll("div, section, article"));
      const rankedBackgrounds = bgCandidates
        .map((node) => {
          if (isIrrelevantNode(node)) return { url: "", score: 0 };
          const inlineUrl = cssImageUrl(node.style?.backgroundImage);
          const computedUrl = inlineUrl || cssImageUrl(window.getComputedStyle(node).backgroundImage);
          return { url: computedUrl, score: viewportMediaScore(node) };
        })
        .filter((item) => item.score > 0 && !isBadImage(item.url))
        .sort((a, b) => b.score - a.score);
      if (rankedBackgrounds[0]?.url) return { url: rankedBackgrounds[0].url, source: "viewport-background", top: rankedBackgrounds.slice(0, 5) };
      return { url: "", source: "viewport-none", top: [] };
    };
    const pickBackgroundThumbnail = () => {
      const candidates = Array.from(noteRoot.querySelectorAll("div, section, article"));
      const ranked = candidates
        .map((node) => {
          if (isIrrelevantNode(node)) return { url: "", score: 0 };
          const inlineUrl = cssImageUrl(node.style?.backgroundImage);
          const computedUrl = inlineUrl || cssImageUrl(window.getComputedStyle(node).backgroundImage);
          return { url: computedUrl, score: backgroundScore(node) };
        })
        .filter((item) => item.score > 0 && !isBadImage(item.url))
        .sort((a, b) => b.score - a.score);
      return { url: ranked[0]?.url || "", top: ranked.slice(0, 5) };
    };
    const pickThumbnail = () => {
      const debug = {
        titleText: titleNode?.textContent?.trim() || "",
        noteRootTag: noteRoot?.tagName || "",
        noteRootClass: noteRoot?.className || "",
      };

      const viewportThumb = pickViewportThumbnail();
      debug.viewport = viewportThumb;
      if (viewportThumb.url && !isBadImage(viewportThumb.url)) return { url: viewportThumb.url, source: viewportThumb.source, debug };

      const poster = normalizeImageUrl(first([
        "video[poster]",
        ".media-container video[poster]",
        "[class*='media'] video[poster]",
      ], noteRoot)?.getAttribute("poster"));
      debug.poster = poster;
      if (poster && !isBadImage(poster)) return { url: poster, source: "note-video-poster", debug };

      const og = normalizeImageUrl(document.querySelector("meta[property='og:image']")?.content);
      debug.og = og;
      if (og && !isBadImage(og)) return { url: og, source: "og-image", debug };

      const activeSlide = normalizeImageUrl(first([
        ".swiper-slide-active img",
        "[class*='swiper-slide-active'] img",
        "[class*='carousel'] [aria-current='true'] img",
      ], noteRoot)?.currentSrc || first([
        ".swiper-slide-active img",
        "[class*='swiper-slide-active'] img",
        "[class*='carousel'] [aria-current='true'] img",
      ], noteRoot)?.src);
      debug.activeSlide = activeSlide;
      if (activeSlide && !isBadImage(activeSlide)) return { url: activeSlide, source: "note-active-slide", debug };

      const selectors = [
        ".media-container img",
        "[class*='media'] img",
        "[class*='note-slider'] img",
        ".swiper-slide img",
        ".media-container img",
        "[class*='content'] img",
        "img",
      ];
      const candidates = selectors.flatMap((selector) => Array.from(noteRoot.querySelectorAll(selector)));
      const ranked = candidates
        .map((img) => {
          if (isIrrelevantNode(img)) return { url: "", score: 0 };
          const url = normalizeImageUrl(img.currentSrc || img.src || img.getAttribute("src") || img.getAttribute("data-src"));
          return { url, score: visibleScore(img) };
        })
        .filter((item) => item.score > 0 && !isBadImage(item.url))
        .sort((a, b) => b.score - a.score);
      debug.noteImages = ranked.slice(0, 5);
      if (ranked[0]?.url) return { url: ranked[0].url, source: "note-image", debug };
      const bgThumb = pickBackgroundThumbnail();
      debug.noteBackgrounds = bgThumb.top;
      if (bgThumb.url && !isBadImage(bgThumb.url)) return { url: bgThumb.url, source: "note-background", debug };
      return { url: "", source: "none", debug };
    };
    const parseCount = (value) => {
      const cleaned = String(value || "").trim();
      if (cleaned.includes("万")) return Math.round((Number.parseFloat(cleaned) || 0) * 10000);
      return Number.parseInt(cleaned.replace(/[^0-9]/g, ""), 10) || 0;
    };
    const scopedText = (selectors) => {
      for (const selector of selectors) {
        const value = noteRoot.querySelector(selector)?.textContent?.trim();
        if (value) return value;
      }
      return "";
    };
    const title = scopedText(["#detail-title", ".title", "h1"]) || document.title;
    const content = (scopedText(["#detail-desc", ".desc", "[class*='content']"])).slice(0, 1000);
    const thumbnailResult = pickThumbnail();
    const thumbnail = thumbnailResult.url || "";
    const debug = {
      thumbnail_source: thumbnailResult.source,
      ...thumbnailResult.debug,
    };
    window.__pmcopilot_xhs_debug = debug;

    return {
      title,
      content,
      likes: parseCount(text("[class*='like-wrapper'] [class*='count']") || text(".like-count")),
      collects: parseCount(text("[class*='collect-wrapper'] [class*='count']") || text(".collect-count")),
      comments: parseCount(text("[class*='chat-wrapper'] [class*='count']") || text(".comment-count")),
      thumbnail_url: thumbnail,
      author: text("[class*='username']") || text(".author-name"),
      debug,
    };
  };
})();
